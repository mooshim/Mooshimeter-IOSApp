//
//  WYAnotherViewController.h
//  WYPopoverDemo
//
//  Created by Nicolas CHENG on 27/08/13.
//  Copyright (c) 2013 Nicolas CHENG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WYAnotherViewController : UIViewController
{
}

- (IBAction)resizeme:(id)sender;

@end
