//
//  WYAppDelegate.h
//
//  Created by Nicolas CHENG on 14/08/13.
//  Copyright (c) 2013 WHYERS. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WYRootViewController;

@interface WYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) WYRootViewController *rootViewController;

@end
