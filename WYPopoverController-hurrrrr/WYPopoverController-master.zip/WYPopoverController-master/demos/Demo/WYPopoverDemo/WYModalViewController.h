//
//  WYModalViewController.h
//  WYPopoverDemo
//
//  Created by Nicolas CHENG on 14/11/13.
//  Copyright (c) 2013 Nicolas CHENG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WYModalViewController : UIViewController

@end
