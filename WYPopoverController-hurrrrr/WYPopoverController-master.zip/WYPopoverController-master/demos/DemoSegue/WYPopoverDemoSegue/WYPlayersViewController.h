//
//  WYPlayersViewController.h
//  WYPopoverDemoSegue
//
//  Created by Nicolas CHENG on 29/08/13.
//  Copyright (c) 2013 Nicolas CHENG. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WYPlayersViewController : UITableViewController
{
}

@property (nonatomic, strong) NSMutableArray *players;

- (IBAction)showTest:(id)sender;

@end
