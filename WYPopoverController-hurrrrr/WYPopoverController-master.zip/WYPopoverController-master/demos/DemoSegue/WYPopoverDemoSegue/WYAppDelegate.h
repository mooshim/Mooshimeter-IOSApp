//
//  WYAppDelegate.h
//  WYPopoverDemoSegue
//
//  Created by Nicolas CHENG on 28/08/13.
//  Copyright (c) 2013 Nicolas CHENG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WYAppDelegate : UIResponder <UIApplicationDelegate>
{
    NSMutableArray *players;
}

@property (strong, nonatomic) UIWindow *window;

@end
