//
//  WYViewController.m
//  WYPopoverDemoSegue
//
//  Created by Nicolas CHENG on 28/08/13.
//  Copyright (c) 2013 Nicolas CHENG. All rights reserved.
//

#import "WYViewController.h"

@interface WYViewController ()

@end

@implementation WYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
