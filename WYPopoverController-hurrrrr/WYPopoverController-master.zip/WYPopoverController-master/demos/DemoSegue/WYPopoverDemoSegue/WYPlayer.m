//
//  WYPlayer.m
//  WYPopoverDemoSegue
//
//  Created by Nicolas CHENG on 29/08/13.
//  Copyright (c) 2013 Nicolas CHENG. All rights reserved.
//

#import "WYPlayer.h"

@implementation WYPlayer

@synthesize name;
@synthesize game;
@synthesize rating;

@end
